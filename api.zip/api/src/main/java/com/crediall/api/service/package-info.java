/**
 * Service layer beans.
 */
package com.crediall.api.service;
