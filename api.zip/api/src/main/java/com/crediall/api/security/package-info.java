/**
 * Spring Security configuration.
 */
package com.crediall.api.security;
