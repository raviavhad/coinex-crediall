package com.crediall.api.domain.enumeration;

/**
 * The CrediallWalletStatus enumeration.
 */
public enum CrediallWalletStatus {
    AVAILABLE,
    RESTRICTED,
    DISABLED,
}
