/**
 * Spring Data JPA repositories.
 */
package com.crediall.api.repository;
