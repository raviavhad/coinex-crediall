/**
 * Spring MVC REST controllers.
 */
package com.crediall.api.web.rest;
