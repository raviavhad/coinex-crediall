/**
 * Data Transfer Objects.
 */
package com.crediall.api.service.dto;
