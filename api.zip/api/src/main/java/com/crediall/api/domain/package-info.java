/**
 * JPA domain objects.
 */
package com.crediall.api.domain;
