/**
 * View Models used by Spring MVC REST controllers.
 */
package com.crediall.api.web.rest.vm;
